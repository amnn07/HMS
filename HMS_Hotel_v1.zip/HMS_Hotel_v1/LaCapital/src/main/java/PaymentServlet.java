//package web;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import service.ReservationService;

import java.io.IOException;
import java.util.logging.Logger;

/**
 * Servlet implementation class PaymentServlet
 */
@WebServlet("/PaymentServlet")
public class PaymentServlet extends HttpServlet {
    private ReservationService reservationService = new ReservationService();
    private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
	

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String bookingId = request.getParameter("bookingId");
        
        // Update payment status to "paid"
        reservationService.updatePaymentStatus(bookingId, "paid");
        logger.info("Paymnet processing");
        
        // Redirect to payment success page
        response.sendRedirect("paymentSuccess.jsp?bookingId=" + bookingId);
        
    }
}