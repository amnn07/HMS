//package web;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.logging.Logger;

import bean.Reservation;
import service.ReservationService;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

@WebServlet("/GenerateInvoiceServlet")
public class GenerateInvoiceServlet extends HttpServlet {
    private ReservationService reservationService = new ReservationService();
    private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
	
    

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String bookingId = request.getParameter("bookingId");
        if (bookingId == null || bookingId.trim().isEmpty()) {
            response.getWriter().println("Booking ID is required!");
            return;
        }
        Reservation reservation = reservationService.getReservationByBookingId(bookingId);
        if (reservation == null) {
            response.getWriter().println("No booking found with ID: " + bookingId);
            return;
        }

        // Set the response headers to indicate a file download (PDF)
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=invoice_" + bookingId + ".pdf");

        try {
            Document document = new Document();
            PdfWriter.getInstance(document, response.getOutputStream());
            document.open();

            // Build invoice content
            document.add(new Paragraph("Invoice for Booking: " + reservation.getBookingId()));
            
            document.add(new Paragraph("Customer ID: " + reservation.getCustomerId()));
            document.add(new Paragraph("Customer Name: " + reservation.getName()));
            document.add(new Paragraph("Check-in Date: " + reservation.getCheckinDate()));
            document.add(new Paragraph("Check-out Date: " + reservation.getCheckoutDate()));
            document.add(new Paragraph("Room Type: " + reservation.getRoomType()));
            document.add(new Paragraph("Room No: " + (reservation.getRoomNo() != 0 ? reservation.getRoomNo() : "Not Allocated")));
            document.add(new Paragraph("Total Amount: " + reservation.getTotalAmount()));
            document.add(new Paragraph("Payment Status: " + reservation.getPaymentStatus()));
            document.add(new Paragraph("Admin Confirmation: " + (reservation.getAdminConfirmStatus() != null ? reservation.getAdminConfirmStatus() : "Pending")));
            logger.info("generate invoice processing");
            document.close();
           
        } catch (Exception e) {
        	logger.info("Logout processing failed");
            throw new ServletException(e);
            
        }
    }
}
