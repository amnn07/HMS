package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
    private static final String URL = "jdbc:derby:C:\\Users\\2328044\\MyDB;create=true"; // Replace 'hotel_db' with your database name
    private static final String USER = "root"; // Change this if you have a different MySQL username
//    private static final String PASSWORD = "Vedant@03"; // Replace with your MySQL password

    static {
        try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver"); // Load MySQL JDBC Driver
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException("MySQL JDBC Driver not found.");
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }
}
