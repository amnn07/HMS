//package web;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.logging.Logger;

import service.AdminReservationService;

@WebServlet("/AdminReservationServlet")
public class AdminReservationServlet extends HttpServlet {
    private AdminReservationService adminReservationService = new AdminReservationService();
    private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
	

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String bookingId = request.getParameter("bookingId");
        String action = request.getParameter("action");
        String roomNumber = request.getParameter("roomNumber"); // selected from dropdown
    
        adminReservationService.processReservationDecision(bookingId, action, roomNumber);
        logger.info("admin confirmation successful");
        response.sendRedirect("AdminReservationServlet");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setAttribute("reservations", adminReservationService.getAllPendingReservations());
        logger.info("admin confirmation form");
        request.getRequestDispatcher("adminReservation1.jsp").forward(request, response);
    }
}
