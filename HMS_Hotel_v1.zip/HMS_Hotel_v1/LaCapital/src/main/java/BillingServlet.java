//package web;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.ReservationService;

import java.io.IOException;

import java.util.List;
import java.util.logging.Logger;

import bean.Reservation;

/**
 * Servlet implementation class BillingServlet
 */
@WebServlet("/BillingServlet")
public class BillingServlet extends HttpServlet {
    private ReservationService reservationService = new ReservationService();
    private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
	

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
    	
    	HttpSession session = request.getSession();
        String customerId = (String) session.getAttribute("customerId");
        if (customerId == null) {
            response.sendRedirect("customerLogin.jsp");
            return;
        }
        // Get all pending reservations for this customer
        List<Reservation> pendingReservations = reservationService.getPendingReservations(customerId);
        request.setAttribute("pendingReservations", pendingReservations);
        logger.info("customer billingprocessing");
        request.getRequestDispatcher("billing.jsp").forward(request, response);
     
    }
}