//package web;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import bean.Feedback;
import service.AdminSupportService;

@WebServlet("/AdminSupportServlet")
public class AdminSupportServlet extends HttpServlet {
    private AdminSupportService supportService = new AdminSupportService();
    private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
	

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	System.out.println("hiii");    
    	List<Feedback> feedbackList = supportService.getAllFeedback();
    	System.out.println("Feedback list size: " + feedbackList.size());
    	request.setAttribute("feedbackList", feedbackList);
    	logger.info("Admin Support processing");
    	request.getRequestDispatcher("AdminSupport.jsp").forward(request, response);
    	
    }
}
