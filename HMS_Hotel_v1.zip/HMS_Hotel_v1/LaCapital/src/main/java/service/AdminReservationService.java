package service;

import bean.Reservation;
import dao.AdminReservationDao;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;

public class AdminReservationService {
    private AdminReservationDao adminReservationDao = new AdminReservationDao();
    private RoomService roomService = new RoomService();

    /**
     * Processes the admin's decision for a reservation.
     * For "approve", uses the selected room number (as a String) from the available rooms dropdown.
     */
    public void processReservationDecision(String bookingId, String action, String roomNumber) {
        Reservation reservation = adminReservationDao.getReservationById(bookingId);
        if (reservation == null) return;
        if (!"paid".equalsIgnoreCase(reservation.getPaymentStatus())) return;

        if ("approve".equalsIgnoreCase(action)) {
            if (roomNumber == null || roomNumber.trim().isEmpty()) return;
            try {
                int allocatedRoomNo = Integer.parseInt(roomNumber.trim());
                LocalDate checkin = reservation.getCheckinDate().toLocalDate();
                LocalDate checkout = reservation.getCheckoutDate().toLocalDate();
                if (!roomService.isRoomAvailable(allocatedRoomNo, reservation.getRoomType(), checkin, checkout)) {
                    // Room is not available; do not approve.
                    return;
                }
                // Room is available: update reservation and book the room.
                reservation.setAdminConfirmStatus("approved");
                reservation.setRoomNo(allocatedRoomNo);
                adminReservationDao.updateAdminStatus(bookingId, "approved", allocatedRoomNo);
                roomService.bookRoom(allocatedRoomNo, reservation.getCheckinDate(), reservation.getCheckoutDate(), reservation.getCustomerId());
                saveReservationToFile(reservation, "confirmed_reservations.txt");
            } catch (NumberFormatException e) {
                e.printStackTrace();
                return;
            }
        } else if ("reject".equalsIgnoreCase(action)) {
            reservation.setAdminConfirmStatus("rejected");
            reservation.setRoomNo(0);
            adminReservationDao.updateAdminStatus(bookingId, "rejected", 0);
            saveReservationToFile(reservation, "rejected_reservations.txt");
        }
    }

    private void saveReservationToFile(Reservation reservation, String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            String line = reservation.getBookingId() + "," +
                          reservation.getCustomerId() + "," +
                          reservation.getName() + "," +
                          reservation.getCheckinDate() + "," +
                          reservation.getCheckoutDate() + "," +
                          reservation.getRoomType() + "," +
                          reservation.getPaymentStatus() + "," +
                          reservation.getAdminConfirmStatus() + "," +
                          reservation.getRoomNo() +
                          "\n";
            writer.write(line);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public java.util.List<Reservation> getAllPendingReservations() {
        return adminReservationDao.getAllPendingReservations();
    }
}
