package service;

import dao.ReservationDAO;
import bean.Reservation;

import java.util.List;
import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class ReservationService {
    private ReservationDAO reservationDAO = new ReservationDAO();

    public String generateBookingId() {
        // Generate a booking id using a prefix and current timestamp
        return "BOOK" + System.currentTimeMillis();
    }

    public int calculateDays(LocalDate checkin, LocalDate checkout) {
        return (int) ChronoUnit.DAYS.between(checkin, checkout);
    }

    public int calculateTotalAmount(String roomType, int days) {
        int rate = 0;
        switch (roomType) {
            case "Single":
                rate = 400;
                break;
            case "Double":
                rate = 600;
                break;
            case "Suit":
                rate = 800;
                break;
        }
        return rate * days;
    }

    public Reservation processReservation(String customerId, String checkinStr, String checkoutStr, String roomType, String name, String contact) {
        LocalDate checkinDate = LocalDate.parse(checkinStr);
        LocalDate checkoutDate = LocalDate.parse(checkoutStr);
        int days = calculateDays(checkinDate, checkoutDate);
        int totalAmount = calculateTotalAmount(roomType, days);
        String bookingId = generateBookingId();

        Reservation reservation = new Reservation();
        reservation.setBookingId(bookingId);
        reservation.setCustomerId(customerId);
        reservation.setCheckinDate(Date.valueOf(checkinDate));
        reservation.setCheckoutDate(Date.valueOf(checkoutDate));
        reservation.setRoomType(roomType);
        reservation.setName(name);
        reservation.setContact(contact);
        reservation.setNumberOfDays(days);
        reservation.setTotalAmount(totalAmount);
        reservation.setPaymentStatus("pending");

        // Save reservation to the database
        reservationDAO.saveReservation(reservation);
        return reservation;
    }

  
    
 // In service/ReservationService.java
    public Reservation getPendingReservation(String customerId) {
        return reservationDAO.getPendingReservation(customerId);
    }
    
 // In service/ReservationService.java

    public Reservation getReservationByCustomerAndDate(String customerId, String checkin) {
        return reservationDAO.getReservationByCustomerAndDate(customerId, checkin);
    }
    
    public List<Reservation> getPendingReservations(String customerId) {
        return reservationDAO.getPendingReservations(customerId);
    }
    
    // Method to update payment status remains the same:
    public void updatePaymentStatus(String bookingId, String status) {
        reservationDAO.updatePaymentStatus(bookingId, status);
    }
    
    public List<Reservation> getPastReservations(String customerId) {
        return reservationDAO.getReservationsForPast(customerId);
    }

    public List<Reservation> getUpcomingReservations(String customerId) {
        return reservationDAO.getReservationsForUpcoming(customerId);
    }
    public List<Reservation> getAllPastReservations() {
        return reservationDAO.getAllPastReservations();
    }

    public List<Reservation> getAllUpcomingReservations() {
        return reservationDAO.getAllUpcomingReservations();
    }
    public List<Reservation> getAllBookings() {
        return reservationDAO.getAllReservations(); // Implement getAllReservations() in your DAO
    }
    public Reservation getReservationByBookingId(String bookingId) {
        return reservationDAO.getReservationById(bookingId);
    }


}
