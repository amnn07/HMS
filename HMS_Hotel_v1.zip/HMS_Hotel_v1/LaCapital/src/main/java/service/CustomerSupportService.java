package service;

import dao.CustomerSupportDao;

public class CustomerSupportService {
    private CustomerSupportDao supportDao = new CustomerSupportDao();

    public void saveFeedback(String bookingId, String customerId, int rating, String message) {
        supportDao.insertFeedback(bookingId, customerId, rating, message);
    }
}
