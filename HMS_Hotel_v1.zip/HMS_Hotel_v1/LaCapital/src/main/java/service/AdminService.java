
package service;

import bean.Admin;
import dao.AdminDAO;

public class AdminService {
    private final AdminDAO adminDAO;

    public AdminService() {
        this.adminDAO = new AdminDAO();
    }

    public boolean validateAdmin(String adminId, String password) {
        Admin admin = adminDAO.getAdminById(adminId);
        if (admin != null) {
            return admin.getPassword().equals(password);
        }
        return false;
    }
}
