package service;

import bean.Room;
import dao.RoomDao;
import dao.ReservationDAO;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class RoomService {
    private RoomDao roomDao = new RoomDao();
    private ReservationDAO reservationDao = new ReservationDAO();

    public List<Room> getAllRooms() {
        return roomDao.getAllRooms();
    }
    
    /**
     * Returns a list of available room numbers (as integers) for a given room type and desired date range.
     */
    public List<Integer> getAvailableRooms(String roomType, LocalDate checkin, LocalDate checkout) {
        List<Room> rooms = roomDao.getAllRooms();
        List<Integer> availableRoomNumbers = new ArrayList<>();
        for (Room room : rooms) {
            if (room.getRoomType().equalsIgnoreCase(roomType)) {
                if (isRoomAvailable(room.getRoomNumber(), roomType, checkin, checkout)) {
                    availableRoomNumbers.add(room.getRoomNumber());
                }
            }
        }
        return availableRoomNumbers;
    }
    
    /**
     * Checks if a specific room is available for booking in the given date range.
     */
    public boolean isRoomAvailable(int roomNo, String roomType, LocalDate desiredCheckin, LocalDate desiredCheckout) {
        Room room = roomDao.getRoomByNumber(roomNo);
        System.out.println(room);
        if (room == null) return false;
        if (!room.getRoomType().equalsIgnoreCase(roomType)) return false;
        boolean booked = reservationDao.isRoomBookedForDateRange(roomNo, desiredCheckin, desiredCheckout);
        System.out.println(booked);
        System.out.println(desiredCheckin);
        return !booked;
    }
    
    /**
     * Books the room by updating its status.
     */
    public void bookRoom(int roomNo, java.sql.Date fromDate, java.sql.Date uptoDate, String userId) {
        roomDao.updateRoomStatus(roomNo, "booked", fromDate, uptoDate, userId);
    }
}
