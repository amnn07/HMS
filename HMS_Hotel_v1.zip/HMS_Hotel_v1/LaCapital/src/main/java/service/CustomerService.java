package service;

import dao.CustomerDAO;
import bean.Customer;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CustomerService {
    private CustomerDAO dao = new CustomerDAO();

    public boolean isCustomerExists(String customerId) {
        return dao.findById(customerId) != null;
    }

    public void registerCustomer(Customer customer) {
        String generatedCustomerId = generateCustomerId(customer.getName());
        customer.setCustomerId(generatedCustomerId);
        dao.save(customer);
    }

    public String generateCustomerId(String name) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String timestamp = sdf.format(new Date());
        String prefix = name.substring(0, Math.min(3, name.length())).toUpperCase();
        return prefix + timestamp;
    }
    
    public Customer validateCustomer(String userId, String password) {
        Customer customer = dao.findById(userId);
        if (customer != null && customer.getPassword().equals(password)) {
            return customer;
        }
        return null;
    }
}
