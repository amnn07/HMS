package service;

import bean.Feedback;
import dao.AdminSupportDao;
import java.util.List;

public class AdminSupportService {
    private AdminSupportDao supportDao = new AdminSupportDao();

    public List<Feedback> getAllFeedback() {
        return supportDao.getAllFeedback();
    }
}
