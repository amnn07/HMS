//package web;


import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Reservation;
import service.ReservationService;

@WebServlet("/AdminBillingServlet")
public class AdminBillingServlet extends HttpServlet {
    private ReservationService reservationService = new ReservationService();
    private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
	
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve all bookings. You can modify this to filter by date or payment status as needed.
        List<Reservation> bookings = reservationService.getAllBookings();
        request.setAttribute("bookings", bookings);
        logger.info("Billing successful");
        request.getRequestDispatcher("AdminBilling.jsp").forward(request, response);
    }
}
