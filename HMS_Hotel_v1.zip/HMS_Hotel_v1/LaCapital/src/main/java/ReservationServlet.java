//package web;

import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import service.ReservationService;

import java.io.IOException;
import java.util.logging.Logger;

import bean.Reservation;

/**
 * Servlet implementation class ReservationServlet
 */
@WebServlet("/ReservationServlet")
public class ReservationServlet extends HttpServlet {
    private ReservationService reservationService = new ReservationService();
    private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
	

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the customer ID from session (ensure the user is logged in)
        HttpSession session = request.getSession();
        String customerId = (String) session.getAttribute("customerId");
        if (customerId == null) {
            response.sendRedirect("customerLogin.jsp");
            return;
        }

        // Retrieve the check-in date from the form (format YYYY-MM-DD)
        String checkin = request.getParameter("checkin");

        // Check if there is already a booking for the same day
        Reservation existing = reservationService.getReservationByCustomerAndDate(customerId, checkin);
        if (existing != null) {
            if ("pending".equalsIgnoreCase(existing.getPaymentStatus())) {
                // If pending, force the user to complete that payment first
                request.setAttribute("billingMessage", "You have a pending booking for this day. Please complete its payment first.");
                request.setAttribute("pendingReservation", existing);
                request.getRequestDispatcher("billing.jsp").forward(request, response);
                return;
            } else {
                // If payment is done, show an error message on the reservation page
                request.setAttribute("reservationError", "You already have a booking for this day.");
                request.getRequestDispatcher("reservation.jsp").forward(request, response);
                return;
            }
        }

        // Retrieve remaining parameters from the reservation form
        String checkout = request.getParameter("checkout");    // Format: YYYY-MM-DD
        String roomType = request.getParameter("roomPreference");
        String name = request.getParameter("name");
        String contact = request.getParameter("contact");

        // Process the reservation (calculates days, amount, generates booking id, and saves the record)
        Reservation reservation = reservationService.processReservation(customerId, checkin, checkout, roomType, name, contact);

        // Forward to the Payment page with booking details
        request.setAttribute("bookingId", reservation.getBookingId());
        request.setAttribute("roomType", reservation.getRoomType());
        request.setAttribute("totalAmount", reservation.getTotalAmount());
        logger.info("reservation processing");
        request.getRequestDispatcher("payment.jsp").forward(request, response);
       
        
        
    }
}