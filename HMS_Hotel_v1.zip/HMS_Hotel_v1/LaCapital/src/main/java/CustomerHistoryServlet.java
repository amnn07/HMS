//package web;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import bean.Reservation;
import service.ReservationService;

@WebServlet("/CustomerHistoryServlet")
public class CustomerHistoryServlet extends HttpServlet {
    private ReservationService reservationService = new ReservationService();
    private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
	

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String customerId = (String) session.getAttribute("customerId");
        if (customerId == null) {
            response.sendRedirect("customerLogin.jsp");
            return;
        }
        List<Reservation> history = reservationService.getPastReservations(customerId);
        request.setAttribute("history", history);
        logger.info("customer history processing");
        request.getRequestDispatcher("customerHistory.jsp").forward(request, response);
       
    }
}
