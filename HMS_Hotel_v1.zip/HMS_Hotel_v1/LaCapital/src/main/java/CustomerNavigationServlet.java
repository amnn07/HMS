//package web;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.logging.Logger;

@WebServlet("/CustomerNavigationServlet")
public class CustomerNavigationServlet extends HttpServlet {
	private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("Sign Up".equals(action)) {
        	logger.info("customer signup");
            response.sendRedirect("customerSignup.jsp");
        } else if ("Login".equals(action)) {
        	logger.info("customer login");
            response.sendRedirect("customerLogin.jsp");
        }
        
    }
}
