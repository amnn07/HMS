//package web;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import bean.Room;
import bean.Reservation;
import service.RoomService;
import dao.ReservationDAO;

@WebServlet("/RoomStatusServlet")
public class RoomStatusServlet extends HttpServlet {
    private RoomService roomService = new RoomService();
    private ReservationDAO reservationDao = new ReservationDAO();
    private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
	

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String statusDateStr = request.getParameter("statusDate");
        LocalDate statusDate;
        if (statusDateStr == null || statusDateStr.trim().isEmpty()) {
            statusDate = LocalDate.now();
            statusDateStr = statusDate.toString();
        } else {
            statusDate = LocalDate.parse(statusDateStr);
        }
        // Get static room data
        List<Room> rooms = roomService.getAllRooms();
        // Build a map: room number -> reservation (if booked on that date)
        Map<Integer, Reservation> reservationMap = new HashMap<>();
        for (Room room : rooms) {
            Reservation res = reservationDao.getReservationForRoomOnDate(room.getRoomNumber(), statusDate);
            if (res != null) {
                reservationMap.put(room.getRoomNumber(), res);
            }
        }
        request.setAttribute("statusDate", statusDateStr);
        request.setAttribute("rooms", rooms);
        request.setAttribute("reservationMap", reservationMap);
        logger.info("Room allocation processing");
        request.getRequestDispatcher("RoomStatus.jsp").forward(request, response);
        
        
    }
}
