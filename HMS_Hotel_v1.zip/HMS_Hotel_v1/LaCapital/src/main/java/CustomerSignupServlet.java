//package web;

import bean.Customer;
import service.CustomerService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.logging.Logger;

@WebServlet("/CustomerSignupServlet")
public class CustomerSignupServlet extends HttpServlet {
    private CustomerService customerService = new CustomerService();
    private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
    
	
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String countryCode = request.getParameter("countryCode");
        String mobile = request.getParameter("mobile");
        String address = request.getParameter("address");
        String password = request.getParameter("password");

        String generatedCustomerId = customerService.generateCustomerId(name);
        System.out.print(generatedCustomerId);

        if (customerService.isCustomerExists(generatedCustomerId)) {
            request.setAttribute("signupError", "Customer already exists.");
            request.getRequestDispatcher("customerSignup.jsp").forward(request, response);
        } else {
            Customer customer = new Customer(name, email, countryCode + mobile, address, generatedCustomerId, password);
            customerService.registerCustomer(customer);

            request.setAttribute("customerId", generatedCustomerId);
            request.getRequestDispatcher("registrationSuccess.jsp").forward(request, response);
        }
        logger.info("customer signup processing");
    }
}
