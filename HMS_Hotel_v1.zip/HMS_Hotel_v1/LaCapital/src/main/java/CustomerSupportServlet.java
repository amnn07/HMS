//package web;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.logging.Logger;

import service.CustomerSupportService;

@WebServlet("/CustomerSupportServlet")
public class CustomerSupportServlet extends HttpServlet {
    private CustomerSupportService supportService = new CustomerSupportService();
    private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
	

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // For GET requests, simply forward to the support JSP.
        request.getRequestDispatcher("CustomerSupport.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Process form submission (feedback, query, etc.)
        String bookingId = request.getParameter("bookingId");
        String ratingStr = request.getParameter("rating");
        String message = request.getParameter("message");
        String customerId = (String) request.getSession().getAttribute("customerId");

        int rating = 0;
        try {
            rating = Integer.parseInt(ratingStr);
        } catch (NumberFormatException e) {
            // Handle invalid input if necessary
        }
        supportService.saveFeedback(bookingId, customerId, rating, message);
        request.setAttribute("successMsg", "Your feedback/query has been submitted successfully.");
        logger.info("Feedback processing");
        request.getRequestDispatcher("CustomerSupport.jsp").forward(request, response);
        
    }
}
