//package web;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import bean.Reservation;
import service.ReservationService;

@WebServlet("/AdminHistoryServlet")
public class AdminHistoryServlet extends HttpServlet {
    private ReservationService reservationService = new ReservationService();
    private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
	
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Reservation> history = reservationService.getAllPastReservations();
        // Debug print: log the size of the returned history
        System.out.println("AdminHistoryServlet: Retrieved " + (history != null ? history.size() : 0) + " past reservations.");
        request.setAttribute("history", history);
        logger.info("Future bookings");
        
        // If your JSP is located in a subfolder, update the path accordingly.
        request.getRequestDispatcher("adminHistory.jsp").forward(request, response);
    }
}
