package dao;

import bean.Room;
import util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RoomDao {
    public Room getRoomByNumber(int roomNo) {
        Room room = null;
        String sql = "SELECT * FROM Room WHERE room_no = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, roomNo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                room = new Room();
                room.setRoomNumber(rs.getInt("room_no"));
                room.setRoomType(rs.getString("room_type"));
                room.setStatus(rs.getString("status"));
                room.setFromDate(rs.getDate("from_date"));
                room.setUptoDate(rs.getDate("upto_date"));
                room.setUserId(rs.getString("user_id"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return room;
    }

    public void updateRoomStatus(int roomNo, String status, Date fromDate, Date uptoDate, String userId) {
        String sql = "UPDATE Room SET status = ?, from_date = ?, upto_date = ?, user_id = ? WHERE room_no = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setDate(2, fromDate);
            ps.setDate(3, uptoDate);
            ps.setString(4, userId);
            ps.setInt(5, roomNo);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Room> getAllRooms() {
        List<Room> list = new ArrayList<>();
        String sql = "SELECT * FROM Room ORDER BY room_no";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Room room = new Room();
                room.setRoomNumber(rs.getInt("room_no"));
                room.setRoomType(rs.getString("room_type"));
                room.setStatus(rs.getString("status"));
                room.setFromDate(rs.getDate("from_date"));
                room.setUptoDate(rs.getDate("upto_date"));
                room.setUserId(rs.getString("user_id"));
                list.add(room);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<Room> getBookedRooms() {
        List<Room> list = new ArrayList<>();
        String sql = "SELECT * FROM Room WHERE status = 'booked' ORDER BY room_no";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Room room = new Room();
                room.setRoomNumber(rs.getInt("room_no"));
                room.setRoomType(rs.getString("room_type"));
                room.setStatus(rs.getString("status"));
                room.setFromDate(rs.getDate("from_date"));
                room.setUptoDate(rs.getDate("upto_date"));
                room.setUserId(rs.getString("user_id"));
                list.add(room);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
