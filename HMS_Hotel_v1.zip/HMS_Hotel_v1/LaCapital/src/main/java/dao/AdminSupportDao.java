package dao;

import bean.Feedback;
import util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdminSupportDao {
	
    public List<Feedback> getAllFeedback() {
    	System.out.println("Hello");    
        List<Feedback> list = new ArrayList<>();
        String sql = "SELECT * FROM feedback ORDER BY feedback_date DESC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Feedback fb = new Feedback();
                fb.setFeedbackId(rs.getInt("feedback_id"));
                fb.setBookingId(rs.getString("booking_id"));
                fb.setCustomerId(rs.getString("customer_id"));
                fb.setRoomNo(rs.getInt("room_no"));
                fb.setRating(rs.getInt("rating"));
                fb.setMessage(rs.getString("message"));
                fb.setFeedbackDate(rs.getDate("feedback_date"));
                list.add(fb);
                System.out.println(fb);            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
