package dao;

import util.DBUtil;
import java.sql.*;

public class CustomerSupportDao {

    public void insertFeedback(String bookingId, String customerId, int rating, String message) {
        String sql = "INSERT INTO feedback (booking_id, customer_id, rating, message) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, bookingId);
            ps.setString(2, customerId);
            ps.setInt(3, rating);
            ps.setString(4, message);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
