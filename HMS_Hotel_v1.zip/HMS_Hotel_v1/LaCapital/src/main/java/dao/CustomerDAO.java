package dao;




import bean.Customer;
import bean.Reservation;
import util.DBUtil;

import java.sql.*;

public class CustomerDAO {

    public Customer findById(String customerId) {
        Customer customer = null;
        String query = "SELECT * FROM customers WHERE customer_id = ?";

        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, customerId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                customer = new Customer(
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("mobile"),
                        rs.getString("address"),
                        rs.getString("customer_id"),
                        rs.getString("password")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customer;
    }

    public void save(Customer customer) {
        String query = "INSERT INTO customers (name, email, mobile, address, customer_id, password) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, customer.getName());
            ps.setString(2, customer.getEmail());
            ps.setString(3, customer.getMobile());
            ps.setString(4, customer.getAddress());
            ps.setString(5, customer.getCustomerId());
            ps.setString(6, customer.getPassword());

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
   
}
