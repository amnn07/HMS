package dao;

import bean.Reservation;
import util.DBUtil;
import java.sql.*;
import java.sql.Date;
import java.util.*;
import java.sql.*;
import java.time.LocalDate;



public class ReservationDAO {
    public void saveReservation(Reservation reservation) {
        String sql = "INSERT INTO reservations (booking_id, customer_id, checkin_date, checkout_date, room_type, name, contact, total_amount, payment_status, number_of_days) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, reservation.getBookingId());
            ps.setString(2, reservation.getCustomerId());
            ps.setDate(3, reservation.getCheckinDate());
            ps.setDate(4, reservation.getCheckoutDate());
            ps.setString(5, reservation.getRoomType());
            ps.setString(6, reservation.getName());
            ps.setString(7, reservation.getContact());
            ps.setInt(8, reservation.getTotalAmount());
            ps.setString(9, reservation.getPaymentStatus());
            ps.setInt(10, reservation.getNumberOfDays());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updatePaymentStatus(String bookingId, String status) {
        String sql = "UPDATE reservations SET payment_status = ? WHERE booking_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, bookingId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Reservation getReservationById(String bookingId) {
        Reservation reservation = null;
        String sql = "SELECT * FROM reservations WHERE booking_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, bookingId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                reservation = new Reservation();
                reservation.setBookingId(rs.getString("booking_id"));
                reservation.setCustomerId(rs.getString("customer_id"));
                reservation.setCheckinDate(rs.getDate("checkin_date"));
                reservation.setCheckoutDate(rs.getDate("checkout_date"));
                reservation.setRoomType(rs.getString("room_type"));
                reservation.setName(rs.getString("name"));
                reservation.setContact(rs.getString("contact"));
                reservation.setTotalAmount(rs.getInt("total_amount"));
                reservation.setPaymentStatus(rs.getString("payment_status"));
                reservation.setNumberOfDays(rs.getInt("number_of_days"));
                reservation.setRoomNo(rs.getInt("room_no"));
                reservation.setAdminConfirmStatus(rs.getString("admin_confirm_status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reservation;
    }
    public Reservation getPendingReservation(String customerId) {
        Reservation reservation = null;
        String sql = "SELECT * FROM reservations WHERE customer_id = ? AND payment_status = 'pending' LIMIT 1";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, customerId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                reservation = new Reservation();
                reservation.setBookingId(rs.getString("booking_id"));
                reservation.setCustomerId(rs.getString("customer_id"));
                reservation.setCheckinDate(rs.getDate("checkin_date"));
                reservation.setCheckoutDate(rs.getDate("checkout_date"));
                reservation.setRoomType(rs.getString("room_type"));
                reservation.setName(rs.getString("name"));
                reservation.setContact(rs.getString("contact"));
                reservation.setTotalAmount(rs.getInt("total_amount"));
                reservation.setPaymentStatus(rs.getString("payment_status"));
                reservation.setNumberOfDays(rs.getInt("number_of_days"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reservation;
    }
    
    public Reservation getReservationByCustomerAndDate(String customerId, String checkin) {
        Reservation reservation = null;
        String sql = "SELECT * FROM reservations WHERE customer_id = ? AND checkin_date = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, customerId);
            // Convert checkin (String, format YYYY-MM-DD) to java.sql.Date
            ps.setDate(2, java.sql.Date.valueOf(checkin));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                reservation = new Reservation();
                reservation.setBookingId(rs.getString("booking_id"));
                reservation.setCustomerId(rs.getString("customer_id"));
                reservation.setCheckinDate(rs.getDate("checkin_date"));
                reservation.setCheckoutDate(rs.getDate("checkout_date"));
                reservation.setRoomType(rs.getString("room_type"));
                reservation.setName(rs.getString("name"));
                reservation.setContact(rs.getString("contact"));
                reservation.setTotalAmount(rs.getInt("total_amount"));
                reservation.setPaymentStatus(rs.getString("payment_status"));
                reservation.setNumberOfDays(rs.getInt("number_of_days"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reservation;
    }
    
    public List<Reservation> getPendingReservations(String customerId) {
        List<Reservation> pendingList = new ArrayList<>();
        String sql = "SELECT * FROM reservations WHERE customer_id = ? AND payment_status = 'pending'";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, customerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Reservation reservation = new Reservation();
                reservation.setBookingId(rs.getString("booking_id"));
                reservation.setCustomerId(rs.getString("customer_id"));
                reservation.setCheckinDate(rs.getDate("checkin_date"));
                reservation.setCheckoutDate(rs.getDate("checkout_date"));
                reservation.setRoomType(rs.getString("room_type"));
                reservation.setName(rs.getString("name"));
                reservation.setContact(rs.getString("contact"));
                reservation.setTotalAmount(rs.getInt("total_amount"));
                reservation.setPaymentStatus(rs.getString("payment_status"));
                reservation.setNumberOfDays(rs.getInt("number_of_days"));
                pendingList.add(reservation);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pendingList;
    }
    
    public boolean isRoomBookedForDateRange(int roomNo, LocalDate desiredCheckin, LocalDate desiredCheckout) {
        boolean isBooked = false;
        String sql = "SELECT COUNT(*) FROM reservations " +
                     "WHERE room_no = ? " +
                     "AND admin_confirm_status = 'approved' " +
                     "AND payment_status = 'paid' " +
                     "AND NOT (checkout_date <= ? OR checkin_date >= ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, roomNo);
            ps.setDate(2, Date.valueOf(desiredCheckin));
            ps.setDate(3, Date.valueOf(desiredCheckout));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                if (count > 0) {
                    isBooked = true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return isBooked;
    }

    
    public Reservation getReservationForRoomOnDate(int roomNo, LocalDate date) {
        Reservation reservation = null;
        String sql = "SELECT * FROM reservations WHERE room_no = ? " +
                     "AND admin_confirm_status = 'approved' " +
                     "AND payment_status = 'paid' " +
                     "AND ? BETWEEN checkin_date AND checkout_date";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, roomNo);
            ps.setDate(2, java.sql.Date.valueOf(date));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                reservation = new Reservation();
                reservation.setBookingId(rs.getString("booking_id"));
                reservation.setCustomerId(rs.getString("customer_id"));
                reservation.setCheckinDate(rs.getDate("checkin_date"));
                reservation.setCheckoutDate(rs.getDate("checkout_date"));
                reservation.setRoomType(rs.getString("room_type"));
                reservation.setName(rs.getString("name"));
                reservation.setContact(rs.getString("contact"));
                reservation.setTotalAmount(rs.getInt("total_amount"));
                reservation.setPaymentStatus(rs.getString("payment_status"));
                reservation.setNumberOfDays(rs.getInt("number_of_days"));
                reservation.setAdminConfirmStatus(rs.getString("admin_confirm_status"));
                reservation.setRoomNo(rs.getInt("room_no"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reservation;
    }
    
    public List<Reservation> getReservationsForPast(String customerId) {
        List<Reservation> list = new ArrayList<>();
        String sql = "SELECT * FROM reservations WHERE customer_id = ? AND checkout_date < CURRENT_DATE ORDER BY checkin_date DESC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, customerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Reservation res = new Reservation();
                res.setBookingId(rs.getString("booking_id"));
                res.setCustomerId(rs.getString("customer_id"));
              //  res.setBookingDate(rs.getDate("booking_date"));  // assuming you have getter/setter
                res.setCheckinDate(rs.getDate("checkin_date"));
                res.setCheckoutDate(rs.getDate("checkout_date"));
                res.setRoomType(rs.getString("room_type"));
                res.setName(rs.getString("name"));
                res.setContact(rs.getString("contact"));
                res.setTotalAmount(rs.getInt("total_amount"));
                res.setPaymentStatus(rs.getString("payment_status"));
                res.setNumberOfDays(rs.getInt("number_of_days"));
                res.setAdminConfirmStatus(rs.getString("admin_confirm_status"));
                res.setRoomNo(rs.getInt("room_no"));
                list.add(res);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Reservation> getReservationsForUpcoming(String customerId) {
        List<Reservation> list = new ArrayList<>();
        String sql = "SELECT * FROM reservations WHERE customer_id = ? AND checkin_date >= CURRENT_DATE ORDER BY checkin_date ASC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, customerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Reservation res = new Reservation();
                res.setBookingId(rs.getString("booking_id"));
                res.setCustomerId(rs.getString("customer_id"));
                //res.setBookingDate(rs.getDate("booking_date"));  // assuming you have getter/setter for booking_date
                res.setCheckinDate(rs.getDate("checkin_date"));
                res.setCheckoutDate(rs.getDate("checkout_date"));
                res.setRoomType(rs.getString("room_type"));
                res.setName(rs.getString("name"));
                res.setContact(rs.getString("contact"));
                res.setTotalAmount(rs.getInt("total_amount"));
                res.setPaymentStatus(rs.getString("payment_status"));
                res.setNumberOfDays(rs.getInt("number_of_days"));
                res.setAdminConfirmStatus(rs.getString("admin_confirm_status"));
                res.setRoomNo(rs.getInt("room_no"));
                list.add(res);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    /**
     * Checks if a room (roomNo) is booked (overlapping any approved reservation) for a given date range.
     */
    public List<Reservation> getAllPastReservations() {
        List<Reservation> list = new ArrayList<>();
        String sql = "SELECT * FROM reservations WHERE checkout_date < CURRENT_DATE ORDER BY checkin_date DESC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Reservation res = new Reservation();
                res.setBookingId(rs.getString("booking_id"));
                res.setCustomerId(rs.getString("customer_id"));
                 // ensure your table has booking_date
                res.setCheckinDate(rs.getDate("checkin_date"));
                res.setCheckoutDate(rs.getDate("checkout_date"));
                res.setRoomType(rs.getString("room_type"));
                res.setName(rs.getString("name"));
                res.setContact(rs.getString("contact"));
                res.setTotalAmount(rs.getInt("total_amount"));
                res.setPaymentStatus(rs.getString("payment_status"));
                res.setNumberOfDays(rs.getInt("number_of_days"));
                res.setAdminConfirmStatus(rs.getString("admin_confirm_status"));
                res.setRoomNo(rs.getInt("room_no"));
                list.add(res);
                System.out.println(res);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Reservation> getAllUpcomingReservations() {
        List<Reservation> list = new ArrayList<>();
        String sql = "SELECT * FROM reservations WHERE checkin_date >= CURRENT_DATE ORDER BY checkin_date ASC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Reservation res = new Reservation();
                res.setBookingId(rs.getString("booking_id"));
                res.setCustomerId(rs.getString("customer_id"));
               // res.setBookingDate(rs.getDate("booking_date")); // ensure your table has booking_date
                res.setCheckinDate(rs.getDate("checkin_date"));
                res.setCheckoutDate(rs.getDate("checkout_date"));
                res.setRoomType(rs.getString("room_type"));
                res.setName(rs.getString("name"));
                res.setContact(rs.getString("contact"));
                res.setTotalAmount(rs.getInt("total_amount"));
                res.setPaymentStatus(rs.getString("payment_status"));
                res.setNumberOfDays(rs.getInt("number_of_days"));
                res.setAdminConfirmStatus(rs.getString("admin_confirm_status"));
                res.setRoomNo(rs.getInt("room_no"));
                list.add(res);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    public List<Reservation> getAllReservations() {
        List<Reservation> list = new ArrayList<>();
        String sql = "SELECT * FROM reservations ORDER BY checkin_date";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Reservation res = new Reservation();
                res.setBookingId(rs.getString("booking_id"));
                res.setCustomerId(rs.getString("customer_id"));
              
                res.setCheckinDate(rs.getDate("checkin_date"));
                res.setCheckoutDate(rs.getDate("checkout_date"));
                res.setRoomType(rs.getString("room_type"));
                res.setName(rs.getString("name"));
                res.setContact(rs.getString("contact"));
                res.setTotalAmount(rs.getInt("total_amount"));
                res.setPaymentStatus(rs.getString("payment_status"));
                res.setNumberOfDays(rs.getInt("number_of_days"));
                res.setAdminConfirmStatus(rs.getString("admin_confirm_status"));
                res.setRoomNo(rs.getInt("room_no"));
                list.add(res);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    

    
}
