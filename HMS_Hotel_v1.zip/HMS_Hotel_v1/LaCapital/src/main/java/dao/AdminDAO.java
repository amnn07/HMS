package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import bean.Admin;
import util.DBUtil;

public class AdminDAO {
    public Admin getAdminById(String adminId) {
        Admin admin = null;

        String query = "SELECT ADMIN_ID, PASSWORD FROM ADMIN WHERE ADMIN_ID = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, adminId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                admin = new Admin(rs.getString("ADMIN_ID"), rs.getString("PASSWORD"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return admin;
    }
}
