package dao;

import bean.Reservation;
import util.DBUtil;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AdminReservationDao {

    public Reservation getReservationById(String bookingId) {
        Reservation reservation = null;
        String sql = "SELECT * FROM reservations WHERE booking_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, bookingId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                reservation = new Reservation();
                reservation.setBookingId(rs.getString("booking_id"));
                reservation.setCustomerId(rs.getString("customer_id"));
                reservation.setCheckinDate(rs.getDate("checkin_date"));
                reservation.setCheckoutDate(rs.getDate("checkout_date"));
                reservation.setRoomType(rs.getString("room_type"));
                reservation.setName(rs.getString("name"));
                reservation.setContact(rs.getString("contact"));
                reservation.setTotalAmount(rs.getInt("total_amount"));
                reservation.setPaymentStatus(rs.getString("payment_status"));
                reservation.setNumberOfDays(rs.getInt("number_of_days"));
                reservation.setAdminConfirmStatus(rs.getString("admin_confirm_status"));
                reservation.setRoomNo(rs.getInt("room_no"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reservation;
    }

    public void updateAdminStatus(String bookingId, String adminStatus, int roomNo) {
        String sql = "UPDATE reservations SET admin_confirm_status = ?, room_no = ? WHERE booking_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, adminStatus);
            ps.setInt(2, roomNo);
            ps.setString(3, bookingId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Reservation> getAllPendingReservations() {
        List<Reservation> list = new ArrayList<>();
        String sql = "SELECT * FROM reservations WHERE admin_confirm_status IS NULL OR admin_confirm_status = 'pending'";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Reservation res = new Reservation();
                res.setBookingId(rs.getString("booking_id"));
                res.setCustomerId(rs.getString("customer_id"));
                res.setCheckinDate(rs.getDate("checkin_date"));
                res.setCheckoutDate(rs.getDate("checkout_date"));
                res.setRoomType(rs.getString("room_type"));
                res.setName(rs.getString("name"));
                res.setContact(rs.getString("contact"));
                res.setTotalAmount(rs.getInt("total_amount"));
                res.setPaymentStatus(rs.getString("payment_status"));
                res.setNumberOfDays(rs.getInt("number_of_days"));
                res.setAdminConfirmStatus(rs.getString("admin_confirm_status"));
                res.setRoomNo(rs.getInt("room_no"));
                list.add(res);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    
}
