package bean;

import java.sql.Date;

public class Room {
    private int roomNumber;
    private String roomType;
    private String status; // "vacant" or "booked"
    private Date fromDate;
    private Date uptoDate;
    private String userId;

    // Existing getters and setters
    public int getRoomNumber() {
        return roomNumber;
    }
    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }
    public String getRoomType() {
        return roomType;
    }
    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    // Add these new methods:
    public Date getFromDate() {
        return fromDate;
    }
    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }
    public Date getUptoDate() {
        return uptoDate;
    }
    public void setUptoDate(Date uptoDate) {
        this.uptoDate = uptoDate;
    }
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
}
