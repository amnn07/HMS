package bean;

public class Customer {
    private String name;
    private String email;
    private String mobile;
    private String address;
    private String customerId;
    private String password;

    public Customer(String name, String email, String mobile, String address, String customerId, String password) {
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.address = address;
        this.customerId = customerId;
        this.password = password;
    }

    // Setters & Getters
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getMobile() { return mobile; }
    public String getAddress() { return address; }
    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }
    public String getPassword() { return password; }
}
