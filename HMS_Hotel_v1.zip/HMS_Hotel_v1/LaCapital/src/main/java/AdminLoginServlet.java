//package web;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import service.AdminService;



@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
	private static final Logger logger =  Logger.getLogger(AdminLoginServlet.class.getName());
	
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String adminId = request.getParameter("adminId");
        String password = request.getParameter("password");

        
        AdminService service = new AdminService();
        boolean isValid = service.validateAdmin(adminId, password);

        if (isValid) {
        	HttpSession session=request.getSession();
        	session.setAttribute("adminId", adminId);
        	logger.info("Login successful");
            response.sendRedirect("adminHome.jsp");
            
        } else {
            request.setAttribute("loginError", "Invalid Admin ID or Password");
            request.getRequestDispatcher("adminLogin.jsp").forward(request, response);
        }
    }
}

