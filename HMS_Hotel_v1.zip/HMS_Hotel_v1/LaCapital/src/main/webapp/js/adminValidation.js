window.onload = function() {
    const form = document.getElementById('adminLoginForm');

    form.onsubmit = function(event) {
        let isValid = true;

        const adminId = document.getElementById('adminId').value.trim();
        const password = document.getElementById('password').value.trim();

        const adminIdError = document.getElementById('adminIdError');
        const passwordError = document.getElementById('passwordError');

        // Clear previous errors
        adminIdError.innerText = "";
        passwordError.innerText = "";

        // Admin ID validation (min 5, max 20)
        if (adminId.length < 5 || adminId.length > 20) {
            adminIdError.innerText = "Admin ID must be between 5 and 20 characters.";
            isValid = false;
        }

        // Password validation (8-30 characters with upper, lower, special char)
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\W).{8,30}$/;
        if (!passwordRegex.test(password)) {
            passwordError.innerText = "Password must be 8-30 characters and contain upper, lower, and special character.";
            isValid = false;
        }

        // If validation fails, prevent form submission
        if (!isValid) {
            event.preventDefault();
        }
    };
};
