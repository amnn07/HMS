window.onload = function() {
    document.getElementById('signupForm').onsubmit = function(event) {
        let isValid = true;

        // Name Validation
        let name = document.getElementById('name').value.trim();
        document.getElementById('nameError').innerText = (name.length > 50) ? "Max 50 characters allowed." : "";

        if (name.length > 50) isValid = false;

        // Email
        let email = document.getElementById('email').value.trim();
        let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        document.getElementById('emailError').innerText = emailPattern.test(email) ? "" : "Invalid email format.";

        if (!emailPattern.test(email)) isValid = false;

        // Mobile
        let mobile = document.getElementById('mobile').value.trim();
        document.getElementById('mobileError').innerText = (/^\d{10}$/).test(mobile) ? "" : "Enter valid 10 digit number.";

        if (!/^\d{10}$/.test(mobile)) isValid = false;

        // Address
        let address = document.getElementById('address').value.trim();
        document.getElementById('addressError').innerText = address === "" ? "Address required." : "";

        if (address === "") isValid = false;

        // Customer ID
        let customerId = document.getElementById('customerId').value.trim();
        document.getElementById('customerIdError').innerText = (customerId.length < 5 || customerId.length > 2007) ? "ID length must be 5 to 2007." : "";

        if (customerId.length < 5 || customerId.length > 2007) isValid = false;

        // Password
        let password = document.getElementById('password').value.trim();
        let passPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\W).{8,30}$/;
        document.getElementById('passwordError').innerText = passPattern.test(password) ? "" : "Weak password.";

        if (!passPattern.test(password)) isValid = false;

        // Confirm Password
        let confirmPassword = document.getElementById('confirmPassword').value.trim();
        document.getElementById('confirmPasswordError').innerText = (confirmPassword === password) ? "" : "Passwords do not match.";

        if (confirmPassword !== password) isValid = false;

        if (!isValid) {
            event.preventDefault();
        }
    };
};
